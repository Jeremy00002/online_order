
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# 菜單資料
menu = [
    {"id": 1, "name": "漢堡", "price": 80},
    {"id": 2, "name": "薯條", "price": 50},
    {"id": 3, "name": "可樂", "price": 35},
    {"id": 4, "name": "雞塊", "price": 60},
]

cart = []

@app.route('/')
def index():
    return render_template('index.html', menu=menu)

@app.route('/add_to_cart/<int:item_id>')
def add_to_cart(item_id):
    for item in menu:
        if item["id"] == item_id:
            cart.append(item)
            break
    return redirect(url_for('index'))

@app.route('/cart')
def view_cart():
    total = sum(item["price"] for item in cart)
    return render_template('cart.html', cart=cart, total=total)

@app.route('/checkout', methods=['POST'])
def checkout():
    payment_method = request.form.get("payment")
    total = sum(item["price"] for item in cart)
    cart.clear()
    return render_template('checkout.html', total=total, payment_method=payment_method)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
